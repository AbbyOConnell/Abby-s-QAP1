// Import the URL module
const { URL } = require('url');

// Create a URL object by parsing a URL string
const urlString = 'http://localhost:3000/';
const url = new URL(urlString);

// Log the various components of the URL
console.log('Protocol:', url.protocol);
console.log('Host:', url.host);
console.log('Hostname:', url.hostname);
console.log('Pathname:', url.pathname);
console.log('Query:', url.searchParams.toString());
console.log('Origin:', url.origin);
