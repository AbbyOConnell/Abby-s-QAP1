// Create a Console object
const { Console } = require('console');
const output = new Console(process.stdout, process.stderr);

// Write events and messages using the Console object
output.log('This is a log message');      // Logs a message to the terminal
output.info('This is an info message');   // Logs an info message to the terminal
output.warn('This is a warning message'); // Logs a warning message to the terminal
output.error('This is an error message'); // Logs an error message to the terminal
