// Import the required modules
const http = require('http');

// Create an HTTP server
const server = http.createServer((request, response) => {
  // Log the incoming request method and URL
  console.log('Received request:', request.method, request.url);

  // Set the response header
  response.setHeader('Content-Type', 'text/plain');
  
  // Send a response to the client
  response.end('Hello, World!\n');
});

// Start the server and listen on port 3000
server.listen(3000, () => {
  console.log('Server is running on http://localhost:3000/');
});
