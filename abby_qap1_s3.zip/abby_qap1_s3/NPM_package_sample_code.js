// Import the Moment package
const moment = require('moment');

// Create an array of events
const events = [
  {
    title: 'Event 1',
    date: '2023-05-16',
    time: '09:00',
  },
  {
    title: 'Event 2',
    date: '2023-05-17',
    time: '14:30',
  },
  {
    title: 'Event 3',
    date: '2023-05-18',
    time: '18:00',
  }
];

// Iterate over each event and log the details
events.forEach(event => {
  const { title, date, time } = event;
  
  // Combine date and time into a single moment object
  const eventDateTime = moment(`${date} ${time}`);
  
  // Format the event date and time
  const formattedDateTime = eventDateTime.format('MMMM Do YYYY, h:mm a');
  
  // Log the event details
  console.log(`Title: ${title}`);
  console.log(`Date and Time: ${formattedDateTime}`);
  console.log('---------------------');
});
